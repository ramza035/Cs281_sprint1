window.onload = function(){
  $("#checkdetail_1").hide();
  var orderID = 0;
  var co = new Vue(
    {
        el : "#checkout",
        data :{
          dat : "aa",
          fname : "",
          lname : "",
          email : "",
          addr : "",
          orr : ""
        },
        methods : {
          next(page){
            if(page == "2"){
              $("#checkdetail").fadeOut();
              $("#checkdetail_1").fadeIn();

            }
            if(page == "1"){
              $("#checkdetail_1").fadeOut();
              $("#checkdetail").fadeIn();
            }

          },
          generateOrder(){
            $.get('Order_gen.php')
              .done(function(res){
                orr = res;
                //alert(orr);
              }.bind(this))
          }
        },
        created : function(){
          this.generateOrder();
        }



    });
}
