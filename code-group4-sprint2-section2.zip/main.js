
window.onload = function(){

    var a = new Vue({
      el : "#app",
      data : {
        username : "",
        password : "",
        firstname : "",
        lastname : "",
        email : "",
        address : "",
        items : [],
        show : [],
        diag : false,
        temp_name : "",
        temp_desc : "",
        temp_price : "",
        temp_pic : "",
        temp_username : "",
        temp_remain : "",
        temp_p : "",
        temp_cat : "",
        prof_open : false,
        cart : [],
        logged : false,
        cart_open : false,
        login_open : false,
        isOpen : false,
        add_pro_open : false,
        curr_cat : "",
        image:"",
        isUpload : false,

              add_product_data : {product_name : "",
                      product_description:"",
                      product_price : "",
                      product_stock : "",
                      product_catagory : "",
                      product_directory : "",

                          },

        headers: [
          {text : "Item Name",value : "iname"},
          {text : "Item Description",value : "idesc"},
          {text : "Item Price",value : "iprice"},
          {text : "Amount",value : "iamount"},
          {text : "Action",value : "iaction"}
        ],
        catagory_items : [
          {
              text : "Assult Rifle",
              id : 0
          },
        {
            text : "Pistol",
            id : 1
        }]
      },
      created : function(){
        this.getJson();
        this.cartFetch();
      },
      methods : {
        getJson : function(){
          $.getJSON('item_fetch.php', function(resp) {
                    this.items = resp;

              }.bind(this));
        },
        clicked : function(){
          alert("Clicked");
        },
        modalDetail(name,desc,price,pic,remaining,cat){
              this.temp_name = name;
              this.temp_desc = desc;
              this.temp_price = price;
              this.temp_pic = pic;
              this.temp_remain = remaining;
              this.temp_cat = cat;

        },
        addToCart(item){
          var bo = false;
          var index = 0;
          if(this.cart.length > 0){
            for(var i = 0 ; i < this.cart.length ; i++){
                if(item.itemname == this.cart[i].itemname){
                    bo = true;
                    index = i;
                    break;
                }
            }
          }
            if(bo == false){
              item['amount'] = 1;
              this.cart.push(item);
            }else{
              this.cart[index].amount = Number(this.cart[index].amount);
              this.cart[index].amount += 1;
              console.log(typeof this.cart[index].amount);
            }
            console.log(this.cart);
            this.toCartSession();
            this.cartFetch();


        },
        authen(usr,pwd){
            $.post("login.php",{use:usr,password:pwd})
              .done(function(data){
                if(data == "success"){
                  window.location = "index.php";

                }else{
                  alert("error");
                }
              })
        },
        logout(){
              axios.get('logout.php')
                        .then(function(response){
                            alert("Logout");
                            window.location = "index.php";
                        }).catch(function(error){
                            alert("Error");
                        });
        },
        click(param){
          if(param == 'reg'){
              this.isOpen = true;
          }
        },
        reg(){
          if(this.username!=""&&this.password!=""&&this.firstname!=""&&this.lastname!=""&&this.email!=""&&this.address!=""){
            $.post('register.php',{
              usr: this.username,
              pswd: this.password,
              fn : this.firstname,
              ln : this.lastname,
              em : this.email,
              ad : this.address})
              .done(function(res){
                if(res=="reg_success"){

                  alert("Account Created");
                }else{
                  alert(res);
                }
              })
          }else{
            alert("Your Information is not completed");
          }


        },
        toCartSession()
        {

            $.get('cart.php',{cart:this.cart})
              .done(function(res){


              })


        },
        cartFetch : function(){
            $.getJSON('cart.php', function(resp) {
                  this.cart = resp;
              }.bind(this));
        },
        product_preview(){
          var temp = "";
          if(this.add_product_data['product_catagory'] == "1"){
            temp = "Pistol";
          }else{
            temp = "Assault Rifle";
          }
          alert("Item name : " + this.add_product_data['product_name'] + "\nDescription : " + this.add_product_data['product_description'] + "\nPrice : " +this.add_product_data['product_price'] + "\nCatagory : " + temp + "\nPath : " + this.add_product_data['product_directory']);
        },

        product_add(){
          if(this.add_product_data['product_name'] != "" &&
          this.add_product_data['product_description'] != "" &&
          this.add_product_data['product_price'] != "" &&
          (this.add_product_data['product_catagory'] != "" || this.add_product_data['product_catagory'] == "0") &&
          this.add_product_data['product_stock'] != "" &&
          (this.add_product_data['product_directory'] != "" || this.add_product_data['product_directory'] == "/upload/"))
          {
            var stock_price_patt = new RegExp('^[0-9]+$');
            if(stock_price_patt.test(this.add_product_data['product_stock']) == true){
              if(stock_price_patt.test(this.add_product_data['product_price']) == true){
                $.get('add_product.php',{add_product: this.add_product_data })
                .done(function(res){
                    alert(res);

                })
              }else{

              }
            }else{
              alert("Stock or price should be number not letter!!");
            }

          }else{
            alert("Error");
            alert("Item name : " + this.add_product_data['product_name'] + "\nDescription : " + this.add_product_data['product_description'] + "\nPrice : " +this.add_product_data['product_price'] + "\nCatagory : " + this.add_product_data['product_catagory'] + "\nPath : " + this.add_product_data['product_directory']);
          }


        },
        deleteItem(item){

          var removableIndex = this.cart.indexOf(item);
          this.cart.splice(removableIndex, 1);
          if(this.cart.length == 0){
            $.get('cart.php',{reset:"true"})
            .done(function(res){

            })
          }
          this.toCartSession();




        },
        totalPrice(){

          var price = 0;
          if(this.cart.length > 0 ){
            for(var i = 0 ; i < this.cart.length ; i++){
                price += (this.cart[i].amount * this.cart[i].price);
            }
            $.get('total_price.php',{total_price: price})
            .done(function(res){
                  //alert(res);
            })
          }


            return price;
        },
        img(path){
            this.add_product_data['product_directory'] = path;
        }






  }


});
//this picture upload code is not working here
  $('form').submit(function(e){
    e.preventDefault();
    var formData = new FormData(this);

      $.ajax({
          type:'POST',
          url: $(this).attr('action'),
          data:formData,
          cache:false,
          contentType: false,
          processData: false,
          success:function(data){
              alert("Picture Uploaded " + data);
              var img = "";
              img += "/upload/"+data;
              a.img(img);
              alert(a.add_product_data['product_directory']);
              alert("Uploaded");
              a.isUpload = true;
          },
          error: function(data){
              console.log("error");
              console.log(data);
          }
      });
  });












}
