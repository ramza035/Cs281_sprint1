<?php
      session_start();


      function manageItem(){
        $host = "localhost";
        $usr = "root";
        $pwd = "";
        $db = "mdb";

        $conn = new mysqli($host,$usr,$pwd,$db);
        mysqli_set_charset($conn,"utf8");
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
            $user_manage = "SELECT * FROM itemstock WHERE product_owner = " .$_SESSION['profID']. "";
            $arr = array();
            if ($result = $conn->query($user_manage)) {


                        while ($row = $result->fetch_assoc()) {
                            $arr[] = $row;
                        }
                        echo json_encode($arr);


              }

      }
      function edit(){
        $host = "localhost";
        $usr = "root";
        $pwd = "";
        $db = "mdb";

        $conn = new mysqli($host,$usr,$pwd,$db);
        mysqli_set_charset($conn,"utf8");
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        $command = "UPDATE itemstock SET itemname =  '".$_REQUEST['name']."' , itemdesc = '".$_REQUEST['desc']."', price = '" .$_REQUEST['price']. "', remaining = '" .$_REQUEST['stock']. "' WHERE itemid = '" .$_REQUEST['itemid']. "'";
        $res = $conn->query($command);
        var_dump($res);
      }
      if(isset($_REQUEST['operate'])){
        if($_REQUEST['operate'] == "edit"){
            edit();
        }
      }
      manageItem();


  ?>
