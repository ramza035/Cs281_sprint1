<?php
session_start();
$host = "localhost";
$usr = "root";
$pwd = "";
$db = "mdb";

$con = new mysqli($host,$usr,$pwd,$db);

if ($con->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
    $item = $_REQUEST['add_product'];

  $qu = "INSERT INTO itemstock(itemname,itemdesc,catagory,price,remaining,img_src,product_owner) VALUES ('".$item["product_name"]."','".$item["product_description"]."','".$item["product_catagory"]."','".$item["product_price"]."','".$item["product_stock"]."','".$item["product_directory"]."','".$_SESSION["profID"]."')";
  if($con->query($qu) === TRUE){
    header("location:index.php");
    }else {
        echo "Error: " . $qu . "<br>" . $con->error;
    }
 ?>
