-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2018 at 06:19 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.1.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `itemstock`
--

CREATE TABLE `itemstock` (
  `itemid` int(5) NOT NULL,
  `itemname` varchar(30) NOT NULL,
  `itemdesc` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_520_ci NOT NULL,
  `catagory` int(1) NOT NULL,
  `price` double NOT NULL,
  `remaining` int(11) NOT NULL,
  `img_src` varchar(255) NOT NULL,
  `product_owner` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itemstock`
--

INSERT INTO `itemstock` (`itemid`, `itemname`, `itemdesc`, `catagory`, `price`, `remaining`, `img_src`, `product_owner`) VALUES
(2, 'm4', 'this is item', 0, 1000, 999, 'm4.jpg', 51),
(3, 'm22', 'this is item', 1, 1001, 999, 'M22.jpg', 51),
(8, 'ak47', 'none', 0, 500, 999, 'ak47.jpg', 51),
(9, 'M1', 'none', 0, 10, 999, 'M1.jpg', 51),
(14, 'RPG', 'ดาเมจ 100\nความเร็ว 15m/s\nระยะยิงไกลสุด180m\nMag Size 1\nศัตรูที่อยู่ในระยะ 8m ตายแน่นอน ในระยะ 10m สร้างดาเมจ 80% ระยะ 12m สร้างดาเมจ 60% ถ้ามีผนังป้องกันดาเมจลด 50%\n\nตอนยิงจรวดมีความเร็ว15m/s', 0, 1230, 231, '/upload/rpg.png', 51);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UID` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `fname` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(40) NOT NULL,
  `permission` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UID`, `name`, `password`, `fname`, `lname`, `address`, `email`, `permission`) VALUES
(51, 'admin', 'admin', 'admin', 'admin', 'admin', 'admin', 1),
(52, 'nuttapon', 'khamkul', 'ณัฐพนธ์', 'ขามกุล', 'thailand ', 'aladen009@hotmail.com', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `itemstock`
--
ALTER TABLE `itemstock`
  ADD PRIMARY KEY (`itemid`),
  ADD KEY `product_owner` (`product_owner`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `itemstock`
--
ALTER TABLE `itemstock`
  MODIFY `itemid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `itemstock`
--
ALTER TABLE `itemstock`
  ADD CONSTRAINT `itemstock_ibfk_1` FOREIGN KEY (`product_owner`) REFERENCES `user` (`UID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
