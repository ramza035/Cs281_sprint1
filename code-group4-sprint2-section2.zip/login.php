<?php

  session_start();
  $host = "localhost";
  $usr = "root";
  $pwd = "";
  $db = "mDB";
  $isCorrect = false;
  $con = mysqli_connect($host,$usr,$pwd,$db);
  mysqli_query($con, "SET NAMES UTF8");



    $sql2 = "SELECT * FROM user WHERE name =  '".$_REQUEST['use']."' AND password =  '".$_REQUEST['password']."'";
    $objQuery = mysqli_query($con,$sql2);
    $objResult = mysqli_fetch_array($objQuery);
    if($objResult){
              $_SESSION['use'] = $objResult['name'];
              $_SESSION['profID'] = $objResult['UID'];
              $_SESSION['fname'] = $objResult['fname'];
              $_SESSION['lname'] = $objResult['lname'];
              $_SESSION['addr'] = $objResult['address'];
              $_SESSION['email'] = $objResult['email'];
              $_SESSION['perm'] = $objResult['permission'];
              echo "success";

    }
    session_write_close();
 ?>
