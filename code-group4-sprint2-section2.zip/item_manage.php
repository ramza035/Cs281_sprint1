<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en" dir="ltr">
  <head>
    <link href='https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons' rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://unpkg.com/vue-picture-input"></script>
    <link href="https://unpkg.com/vuetify/dist/vuetify.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">
    <script src="https://unpkg.com/vue/dist/vue.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.18.0/axios.js"></script>
    <script src="https://unpkg.com/vuetify/dist/vuetify.js"></script>
    <script src="item_manage.js"></script>
    <meta charset="utf-8">
    <title>Web page</title>
  </head>
  <body>
        <div id = "manage_item">
          <v-app>
            <v-toolbar dark>
                <v-toolbar-title>BB Gun Shop</v-toolbar-title>
                  <v-spacer></v-spacer>
                <v-toolbar-items>
                  <?php if(isset($_SESSION['use'])) { ?>
                  <v-menu offset-y>
                      <v-btn flat slot="activator"><v-icon>{{'person'}} </v-icon><?php echo $_SESSION['use'] ?></v-btn>
                      <v-list>
                        <v-list-tile href = "index.php" @click = "">
                            <v-list-tile-title>Back</v-list-tile-title>
                        </v-list-tile>
                      </v-list>
                  </v-menu>

                <?php }else{ ?>
                  <v-btn flat @click = "login_open = true"><v-icon>{{'shopping_cart'}}</v-icon></v-btn>
                  <v-btn flat @click = "login_open = true"><v-icon>{{'vpn_key'}} </v-icon>Login</v-btn>
                <?php } ?>
              </v-toolbar-items>
            </v-toolbar>


            <v-container>
              <v-layout class = "display-2">
                จัดการสินค้า
                <v-flex style = "text-align:right"><v-btn color = "success" href = "index.php">กลับ</v-btn></v-flex>
              </v-layout>
              <br>
                <v-divider></v-divider>
                <br>
                <table border = "1" style = "width:100%;border:1px solid #CCC">
                    <tbody>
                        <tr>
                            <th style = "background-color:#CCC">รหัสสินค้า</th>
                            <th style = "background-color:#CCC">ชื่อ</th>
                            <th style = "background-color:#CCC">รายละเอียดสินค้า</th>
                            <th style = "background-color:#CCC">ราคา</th>
                            <th style = "background-color:#CCC">จำนวน Stock</th>
                            <th style = "background-color:#CCC">จัดการสินค้า</th>
                        </tr>
                        <tr v-for = "item in user_item">
                          <th>{{item.itemid}}</th>
                          <th>{{item.itemname}}</th>
                          <th style = "text-align:left">{{item.itemdesc}}</th>
                          <th >{{item.price}}</th>
                          <th>{{item.remaining}}</th>
                          <th><v-btn @click = "open(item.itemid,item.itemname,item.itemdesc,item.price,item.remaining);manage_open=true;">แก้ไข</v-btn></th>
                        </tr>
                    </tbody>
                </table>
            </v-container>
                  <v-dialog v-model="manage_open"  transition="slide-y-transition" max-width="1000px" max-height="1500px">
                          <v-card >
                            <v-toolbar dark ><v-flex  style = "font-size:25px;margin-left:3%">แก้ไขสินค้า</v-flex></v-toolbar>
                            <br><br>
                            <v-layout row style = "margin-left : 2%;">
                                  <v-flex xs4 ><h2>รหัสสินค้า</h2></v-flex>
                                  <v-flex xs4><v-text-field solo v-model = "temp_itemid" disabled></v-text-field></v-flex>
                            </v-layout >
                            <br>
                            <v-layout row style = "margin-left : 2%">
                                  <v-flex xs4><h2>ชื่อสินค้า</h2></v-flex>
                                  <v-flex xs4><v-text-field solo v-model = "temp_itemname"></v-text-field></v-flex>
                            </v-layout>
                            <br>
                            <v-layout row style = "margin-left : 2%">
                                  <v-flex xs4><h2>รายละเอียดสินค้า</h2></v-flex>
                                  <v-flex xs5><v-text-field solo multi-line v-model = "temp_itemdesc"></v-text-field></v-flex>
                            </v-layout>
                            <br>
                            <v-layout row style = "margin-left : 2%">
                                  <v-flex xs4><h2>ราคา</h2></v-flex>
                                  <v-flex xs4><v-text-field solo v-model = "temp_price"></v-text-field></v-flex>
                            </v-layout>
                            <br>
                            <v-layout row style = "margin-left : 2%">
                                  <v-flex xs4><h2>จำนวน</h2></v-flex>
                                  <v-flex xs4><v-text-field solo v-model = "temp_stock"></v-text-field></v-flex>
                            </v-layout>
                            <v-flex style = "text-align:center">

                              <v-btn @click = "edit_product(temp_itemname,temp_itemdesc,temp_price,temp_stock,temp_itemid)">แก้ไข</v-btn>
                            </v-flex>

                          </v-card>
                  </v-dialog>





          </v-app>


        </div>
  </body>
</html>
