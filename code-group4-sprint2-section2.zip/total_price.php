<?php
        session_start();
        $_SESSION['total_price'] = $_REQUEST['total_price'];
        echo $_SESSION['total_price'];
?>
