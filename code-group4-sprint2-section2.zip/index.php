<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
              <link href='https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons' rel="stylesheet">
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
              <script src="https://unpkg.com/vue-picture-input"></script>
              <link href="https://unpkg.com/vuetify/dist/vuetify.min.css" rel="stylesheet">
              <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">
              <script src="https://unpkg.com/vue/dist/vue.js"></script>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.18.0/axios.js"></script>
              <script src="https://unpkg.com/vuetify/dist/vuetify.js"></script>
              <script src="main.js"></script>
              <link href="zoom_hover.css" rel="stylesheet">
    <title>BB Gun Shop</title>
  </head>
  <body>

    <div id ="app">

      <v-app>
      <v-toolbar dark>
          <v-toolbar-title>BB Gun Shop</v-toolbar-title>
            <v-spacer></v-spacer>
          <v-toolbar-items>
            <?php if(isset($_SESSION['use'])) { ?>
            <v-btn flat @click = "cart_open = true"><v-icon>{{'shopping_cart'}}</v-icon></v-btn>
            <v-menu offset-y>
                <v-btn flat slot="activator"><v-icon>{{'person'}} </v-icon><?php echo $_SESSION['use'] ?></v-btn>
                <v-list>
                    <v-list-tile @click="logout()">
                        <v-list-tile-title>Logout</v-list-tile-title>
                    </v-list-tile>
                    <v-list-tile @click="prof_open = !prof_open">
                        <v-list-tile-title>View Profile</v-list-tile-title>
                    </v-list-tile>
                    <?php if($_SESSION['perm'] == 1) { ?>
                    <v-list-tile @click="add_pro_open = !add_pro_open">
                        <v-list-tile-title>Add Product</v-list-tile-title>
                    </v-list-tile>
                    <v-list-tile href = "item_manage.php">
                        <v-list-tile-title>Manage Product</v-list-tile-title>
                    </v-list-tile>
                  <?php } ?>
                </v-list>
            </v-menu>

          <?php }else{ ?>
            <v-btn flat @click = "login_open = true"><v-icon>{{'shopping_cart'}}</v-icon></v-btn>
            <v-btn flat @click = "login_open = true"><v-icon>{{'vpn_key'}} </v-icon>Login</v-btn>
          <?php } ?>

        </v-toolbar-items>
      </v-toolbar>
          <v-parallax src = "wall.jpg" height=700>
            <div style = "text-align:center;margin-top:1%">
              <span><h3 class="display-3">Welcome To BB Gun Shop</h3></span>
                <br><br>
          </div>
            <div style="text-align:center;margin-top:20%">
            <v-btn @click="$vuetify.goTo('#test')" x-large icon ><img src = "https://static.wixstatic.com/media/6fc31b_c5dda63eb9114dc984895d1cdfedddd3~mv2.gif" width ="100px"></img></v-btn>

            </div>
          </v-parallax>
          <v-flex id = "test"><h5 style = "text-align:center" class = "display-3">Item List</h1></v-flex>
          <v-divider></v-divider>
          <v-divider></v-divider>
          <v-layout style = "margin:0 auto;">

          <v-flex xs12 style = "text-align:center;margin:0 auto;">
            <v-layout wrap style = "text-align:center">
              <!----cards--->

                        <v-card width="200px" class = "zoom" style= "margin-top: 1%;margin-right:2%" v-for = "value in items"  light raised>
                          <v-card-media @click.stop="modalDetail(value.itemname,value.itemdesc,value.price,value.img_src,value.remaining,value.catagory);diag=true" :src= "value.img_src" height="200px" width = "200px"></v-card-media>
                          <v-card-title><h1>{{value.itemname}}</h1></v-card-title>
                          <v-divider></v-divider>
                          <v-card-text style = "text-align:center"><h2>{{value.price}} ฿</h2></v-card-text>
                          <v-flex right>
                                <?php if(isset($_SESSION['use'])){ ?>


                                        <v-btn icon @click.stop = "addToCart(value)">
                                        <v-icon>{{ 'add_shopping_cart' }}</v-icon>

                                </v-btn>

                              <?php }else{ ?>
                                <v-btn icon @click.stop = "login_open = true">
                                <v-icon>{{ 'add_shopping_cart' }}</v-icon>
                                </v-btn>
                              <?php } ?>
                                <v-btn icon @click.native = "value.bool=!value.bool">
                                <v-icon>{{ value.bool ? 'more_vert' : 'more_horiz' }}</v-icon>
                                </v-btn>
                                  <v-slide-y-transition>
                                        <v-card-text v-show="value.bool">
                                          {{value.itemdesc}}
                                        </v-card-text>
                                </v-slide-y-transition>

                          </v-flex>
                        </v-card>
                    </v-layout>

                        <v-dialog  transition="dialog-bottom-transition" v-model="diag" max-width="1000px" max-height="1000px">
                                <v-card >
                                  <v-flex>
                                <div style = "text-align:right;background-color:black">
                                  <v-btn icon @click="diag=false" ><v-icon color="white">{{'close'}}</v-icon></v-btn>
                                </div>
                                  <v-card-title style = "background-color:black">
                                    <span><h1 class = "white--text">{{temp_name}}</h1></span>

                                    <v-spacer></v-spacer>
                                  </v-card-title>
                                </v-flex>
                                  <v-divider></v-divider>
                                  <v-layout>
                                        <v-flex xs4 >
                                          <v-card-media :src = "temp_pic" height ="200px" width="200px" style = "margin:5%"></v-card-media>
                                        </v-flex>
                                        <v-flex xs8 wrap>
                                          <v-card-text><h1>Description : </h1></v-card-text>
                                          <v-card-text><h3>{{temp_desc}}</h3></v-card-text>
                                          <v-divider></v-divider>
                                          <v-card-text><h1>Item In Stock </h1><h2>{{temp_remain}}</h2></v-card-text>
                                        </v-flex>

                                  </v-layout>
                                <v-container>
                                  <v-flex><h4>Related Product</h4></v-flex>
                                  <v-divider></v-divider>
                                  <br>
                                      <v-layout row wrap>
                                          <v-flex xs4 v-for = "item in items" v-if = "item.catagory == temp_cat && item.itemname != temp_name" style = "border:1px solid #CCC" hover>
                                                <v-card-media :src = "item.img_src" width="200px" height = "200px"></v-card-media>
                                                <v-divider></v-divider>
                                                <v-card-title><h3>{{item.itemname}}</h3></v-card-title>
                                                <v-btn icon @click.stop = "addToCart(item)">
                                                <v-icon>{{ 'add_shopping_cart' }}</v-icon>


                                          </v-flex>
                                        </v-layout>
                                </v-container>

                                </v-card>
                              </v-dialog>

                              <v-dialog v-model="cart_open"  transition="slide-y-transition" max-width="1000px" max-height="1500px">
                                      <v-card>
                                        <v-flex>
                                      <div style = "text-align:right;background-color:black">
                                        <v-btn icon @click="cart_open=false" color="white" ><v-icon>{{'close'}}</v-icon></v-btn>
                                      </div>
                                        <div style = "background-color:black" >
                                          <v-layout row><v-flex xs10><h1 class = "white--text" style = "padding-left:20px">Cart</h1></v-flex>

                                                <v-flex xs2 style = "text-align:right;padding-right:100px"><v-btn outline class = "white--text" href="checkout_page.php">Checkout</v-btn></v-flex>

                                          </v-layout>


                                          <v-spacer></v-spacer>
                                        </div>
                                      </v-flex>
                                        <v-divider></v-divider>
                                        <v-data-table :headers="headers" :items="cart" hide-actions style = "font-size:25px">
                                              <template slot="items" slot-scope="props">
                                                <td style = "font-size:20px">{{ props.item.itemname }}</td>
                                                <td style = "font-size:20px">{{ props.item.itemdesc }}</td>
                                                <td style = "font-size:20px">{{ props.item.price }}</td>
                                                <td style = "font-size:20px">{{ props.item.amount }}</td>
                                                <td style = "font-size:20px">
                                                  <v-btn icon class="mx-0" @click="deleteItem(props.item)" style = "font-size:25px">
                                                    <v-icon>delete</v-icon>
                                                  </v-btn>
                                                </td>
                                              </template>
                                              <template slot="no-data">

                                              </template>
                                      </v-data-table>
                                      <div style = "background-color:black;text-align:right" >
                                            <a class = "white--text" style = "margin-right:2%;font-size:25px">Total Price : {{totalPrice()}}</a>
                                      </div>
                                      </v-card>
                                    </v-dialog>
                </v-layout>

            </v-flex>
        </v-layout>
        <v-parallax id = "about" src = "about.png" height=700>
          <div style = "text-align:center;margin-top:1%">
            <span><h3 class="display-1"></h3></span>

              <br><br>

        </div>
          <div style="text-align:center;margin-top:20%">


          </div>
        </v-parallax>
        <v-dialog v-model="login_open" max-width="500px" max-height="500px" transition="fade-transition">
                <v-card >
                  <v-card-title style = "background-color:black"><h1 class = "white--text"> Login</h1>
                  </v-card-title>
                </v-flex>
                  <v-divider></v-divider>
                  <v-layout >
                    <div style = "margin:auto">
                      <v-form>
                                  <v-card-title><h2>Username</h2></v-card-title>
                                  <v-text-field v-model="temp_username" :counter="10" label="Name" required></v-text-field>
                                  <v-card-title><h2>Password</h2></v-card-title>
                                  <v-text-field v-model="temp_p" :type = "'password'" label="password" required></v-text-field>
                                  <v-btn color="default" @click="authen(temp_username,temp_p)">Login</v-btn><br><br>
                                  <h3>No Account?<a @click = "click('reg');login_open=false"> Register</a></h3><br><br><br>
                     </v-form>
                    </div>
                  </v-layout>
                </v-card>
              </v-dialog>


              <v-dialog v-model="add_pro_open" fullscreen max-width="800px" max-height="1000px" transition="fade-transition">
                      <v-card >
                        <v-card-title style = "background-color:black;"><h1 class = "white--text"> Add Product</h1>
                        </v-card-title>
                      </v-flex>
                        <v-divider></v-divider>
                        <v-layout >
                          <div style = "margin:auto">
                            <v-form>
                                        <h3 >Product Name<sup class = "red--text">*</sup></h3>
                                        <v-text-field v-model = "add_product_data['product_name']" solo label = "Product Name" ></v-text-field>
                                        <h3>Product Description<sup class = "red--text">*</sup></h3>
                                        <v-text-field multi-line v-model = "add_product_data['product_description']" solo label = "Description"></v-text-field>
                                        <h3>Price<sup class = "red--text">*</sup></h3>
                                        <v-text-field v-model = "add_product_data['product_price']" solo label = "Price"></v-text-field>
                                        <h3>Item in stock<sup class = "red--text">*</sup></h3>
                                        <v-text-field v-model = "add_product_data['product_stock']" solo label = "Item in stock"></v-text-field>
                                        <h3>Catagory<sup class = "red--text">*</sup></h3>
                                        <v-select v-model = "add_product_data['product_catagory']" solo :items = "catagory_items" single-line item-value = "id" label = "Select Catagory"></v-select>
                                        <v-container >
                                            <v-layout row  style = "text-align:left;">

                                                <v-flex wrap><form id = "pic_up" action="product_pic.php" method="post" enctype="multipart/form-data"><input type="file" @click = "isUpload = false" name = "fileToUpload"/>
                                                <input type="submit" v-if = "isUpload == false" value="Upload Image" name="submit" id = "sub"/></form>
                                                </v-flex>
                                            </v-layout>

                                        </v-container>
                                        <v-flex style = "text-align:left">
                                                <v-btn color = "success" @click = "product_preview()">Preview</v-btn>
                                                <v-btn @click.stop = "product_add()">Submit</v-btn>
                                        <v-btn color = "red" class = "white--text" @click = "add_pro_open = false">Cancel</v-btn>
                                        <v-flex>

                           </v-form>
                          </div>
                        </v-layout>
                      </v-card>
                    </v-dialog>




              <v-dialog v-model="isOpen" max-width="600" transition="slide-y-transition" style ="text-align:center">
                      <v-card class = "elevation-12">
                        <v-flex style = "background-color:black;text-align:right"><v-btn icon class="white--text" style = "text-align:right" @click = "isOpen = false"><v-icon>{{'close'}}</v-icon></v-btn></v-flex>
                        <v-toolbar style = "background-color:black;text-align:center"><v-spacer><p class = "display-1 white--text" align-center> Register</p></v-spacer>
                        </v-toolbar>

                      </v-flex>
                        <v-divider></v-divider>
                        <v-layout fluid>
                          <div style = "margin:auto;width:50%;">
                            <br>
                            <v-form style = "margin:auto">
                                  <v-layout row>
                                    <v-flex xs4>
                                          <v-subheader>Username</v-subheader>
                                    </v-flex>
                                    <v-flex xs8>
                                      <v-text-field solo v-model="username" label = "Username" required></v-text-field>
                                    </v-flex>

                                  </v-layout>
                                  <v-layout row>
                                    <v-flex xs4>
                                          <v-subheader>Password</v-subheader>
                                    </v-flex>
                                    <v-flex xs8>
                                      <v-text-field solo v-model="password"  label = "Password" :type = "'password'" required></v-text-field>
                                    </v-flex>

                                  </v-layout>
                                  <v-layout row justify-center>
                                    <v-flex xs6>
                                          <v-subheader>First Name</v-subheader>
                                    </v-flex>
                                    <v-flex xs6>
                                          <v-subheader>Last Name</v-subheader>
                                    </v-flex>

                                  </v-layout style = "text-align:center">
                                  <v-layout row>
                                    <v-flex xs6 >
                                           <v-text-field solo v-model="firstname" label = "First Name" required style = "width:80%"></v-text-field>
                                    </v-flex>
                                    <v-flex xs6 >
                                          <v-text-field solo v-model="lastname" label = "Last Name" required style = "width:80%" ></v-text-field>
                                    </v-flex>
                                  </v-layout>
                                  <br>
                                  <v-layout row>
                                    <v-flex xs4>
                                           <v-subheader>Email</v-subheader>
                                    </v-flex>
                                    <v-flex xs8>
                                          <v-text-field solo v-model="email" label = "Email" required></v-text-field>
                                    </v-flex>
                                  </v-layout>
                                  <v-layout row>
                                    <v-flex xs4>
                                           <v-subheader>Address</v-subheader>
                                    </v-flex>
                                    <v-flex xs8>
                                          <v-text-field solo v-model="address" label = "Address" multi-line required></v-text-field>
                                    </v-flex>
                                  </v-layout>
                                        <v-btn color="secondary" @click="reg()">Register</v-btn><br><br>
                           </v-form>
                          </div>
                        </v-layout>
                      </v-card>
                    </v-dialog>



                    <v-dialog v-model="prof_open" max-width="500px" max-height="500px" transition="slide-y-transition" style ="text-align:center">
                            <v-card >

                              <v-flex style = "background-color:black;text-align:right"><v-btn icon class="white--text"  @click = "prof_open = false"><v-icon>{{'close'}}</v-icon></v-btn></v-flex>
                              <v-card-title style = "background-color:black"><h1 class = "white--text"> Profile</h1>

                              </v-card-title>

                            </v-flex>
                              <v-divider></v-divider>
                              <v-layout  >
                                <v-card style = "margin:auto;width:100%">
                                  <v-form style = "">
                                        <v-layout row>
                                          <v-flex xs4>
                                              <img src = "http://icons.iconarchive.com/icons/icons8/ios7/256/Users-User-Male-4-icon.png" width="100px" height="100px" style = "margin-left:3%"></img>
                                          </v-flex>
                                          <v-flex xs8>
                                            <v-layout row style = "margin-left:3%">
                                                    <v-flex xs4>
                                                      <h3>First Name : </h3>
                                                    </v-flex>
                                                    <v-flex xs8>
                                                      <h3><?php echo $_SESSION['fname']; ?></h3>
                                                    </v-flex>

                                            </v-layout>
                                            <v-layout row style = "margin-left:3%">
                                                    <v-flex xs4>
                                                        <h3>Last Name : </h3>
                                                    </v-flex>
                                                    <v-flex xs8>
                                                        <h3><?php echo $_SESSION['lname']; ?></h3>
                                                    </v-flex>
                                            </v-layout>
                                            <v-layout row style = "margin-left:3%" >
                                                    <v-flex xs4>
                                                        <h3>Address : </h3>
                                                    </v-flex>
                                                    <v-flex xs8>
                                                        <h3><?php echo $_SESSION['addr']; ?></h3>
                                                    </v-flex>

                                            </v-layout>
                                            <v-layout row style = "margin-left:3%">
                                                    <v-flex xs4>
                                                        <h3>Email : </h3>
                                                    </v-flex>
                                                    <v-flex xs8>
                                                        <h3><?php echo $_SESSION['email']; ?></h3>
                                                    </v-flex>

                                            </v-layout>
                                            <br>

                                          </v-flex>
                                        </v-layout>
                                 </v-form>
                               </v-card>
                              </v-layout>
                            </v-card>
                          </v-dialog>
      </v-app>

    </div>
  </body>

  <script>


  </script>
</html>
