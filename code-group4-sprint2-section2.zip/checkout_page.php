<?php
require_once("Order_gen.php");  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link href='https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons' rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://unpkg.com/vue-picture-input"></script>
    <link href="https://unpkg.com/vuetify/dist/vuetify.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">
    <script src="https://unpkg.com/vue/dist/vue.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.18.0/axios.js"></script>
    <script src="https://unpkg.com/vuetify/dist/vuetify.js"></script>
    <script src="checkout_page.js"></script>
    <link href="table.css" rel="stylesheet">

    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php if(isset($_SESSION['cart'])) { ?>
        <div id = "checkout">
              <v-app>
                <v-toolbar dark>
                    <v-toolbar-title>BB Gun Shop</v-toolbar-title>
                      <v-spacer></v-spacer>
                    <v-toolbar-items>
                      <?php if(isset($_SESSION['use'])) { ?>

                      <v-menu offset-y>

                          <v-list>
                              <v-list-tile @click="logout()">
                                  <v-list-tile-title>Logout</v-list-tile-title>
                              </v-list-tile>
                              <v-list-tile @click="prof_open = !prof_open">
                                  <v-list-tile-title>View Profile</v-list-tile-title>
                              </v-list-tile>
                              <?php if($_SESSION['perm'] == 1) { ?>
                              <v-list-tile @click="add_pro_open = !add_pro_open">
                                  <v-list-tile-title>Add Product</v-list-tile-title>
                              </v-list-tile>
                            <?php } ?>
                          </v-list>
                      </v-menu>

                    <?php }else{ ?>
                      <v-btn flat @click = "login_open = true"><v-icon>{{'shopping_cart'}}</v-icon></v-btn>
                      <v-btn flat @click = "login_open = true"><v-icon>{{'vpn_key'}} </v-icon>Login</v-btn>
                    <?php } ?>
                  </v-toolbar-items>
                </v-toolbar>
                  <v-container id = "checkdetail" style = "margin:auto;width:50%">
                    <v-card class = "elevation-12">
                      <br>
                    <h1 style = "margin-left : 3%" class = "display-1">Checkout Detail</h1><br>
                    <v-layout row style = "margin-left:3%;margin-right:3%">
                          <v-flex xs2>First Name</v-flex>
                          <v-flex xs10><v-text-field solo v-model = "fname"></v-text-field></v-flex>
                    </v-layout>
                    <br>
                    <v-layout row style = "margin-left:3%;margin-right:3%">
                          <v-flex xs2>Last Name</v-flex>
                          <v-flex xs10><v-text-field solo v-model = "lname"></v-text-field></v-flex>
                    </v-layout>
                    <br>
                    <v-layout row style = "margin-left:3%;margin-right:3%">
                          <v-flex xs2>Email</v-flex>
                          <v-flex xs10><v-text-field solo v-model = "email"></v-text-field></v-flex>
                    </v-layout>
                        <v-flex style = "margin-left:3%;margin-right:3%">Address</v-flex>
                        <v-layout row style = "margin-left:3%;margin-right:3%">
                                <v-flex xs2></v-flex>
                              <v-flex xs10><v-text-field solo multi-line v-model = "addr"></v-text-field></v-flex>
                        </v-layout>
                        <br>
                        <v-flex style = "text-align:center">

                          <v-btn color = "red" class = "white--text" @click = "next('2');">Submit</v-btn>
                          <v-btn href="index.php">Cancel</v-btn>
                        </v-flex>

                  </v-card>
                  </v-container>

                  <v-container id = "checkdetail_1" style = "margin:auto;width:50%">
                    <v-card class = "elevation-12">
                      <br>
                    <h1 style = "margin-left : 3%" class = "display-1">Checkout Detail</h1><br>
                    <v-layout row style = "margin-left:3%;margin-right:3%">
                          <v-flex xs2>Order ID :</v-flex>
                          <v-flex xs10><h4><?php echo $_SESSION['orderID']; ?></h4></v-flex>
                    </v-layout>

                    <v-layout row style = "margin-left:3%;margin-right:3%">
                          <v-flex xs2>Name : </v-flex>
                          <v-flex xs10><h4>{{fname}} {{lname}}</h4></v-flex>
                    </v-layout>

                    <v-layout row style = "margin-left:3%;margin-right:3%">
                          <v-flex xs2>Email</v-flex>
                          <v-flex xs10><h4>{{email}}</h4></v-flex>
                    </v-layout>
                    <br>
                        <v-flex style = "margin-left:3%;margin-right:3%;">Address</v-flex>
                        <v-layout row style = "margin-left:3%;margin-right:3%;border:1px solid #CCC">
                                <v-flex xs2></v-flex>
                              <v-flex xs10><h4>{{addr}}</h4></v-flex>
                        </v-layout>
                        <br>
                        <v-layout row style = "margin-left:3%;margin-right:3%">
                          <table style = "width:100%">
                                <thead>
                                  <tr>
                                      <th>Item Name</th>
                                      <th>Item Price</th>
                                      <th>Amount</th>
                                  </tr>
                                </thead>

                                <tbody>
                                  <?php for($i = 0 ; $i < count($_SESSION['cart']) ; $i++) { ?>
                                  <tr>
                                    <td style = "text-align : center"><?php echo $_SESSION['cart'][$i]['itemname']; ?></td>
                                    <td style = "text-align : center"><?php echo $_SESSION['cart'][$i]['price']; ?></td>
                                    <td style = "text-align : center"><?php echo $_SESSION['cart'][$i]['amount']; ?></td>
                                  </tr>
                                    <?php } ?>
                                </tbody>
                              </table>

                        </v-layout>
                        <br><v-flex style = "margin-left:3%">Total Price : <span style = "color : red"> <?php echo $_SESSION['total_price']; ?></span></v-flex>
                        <v-flex style = "text-align:center">
                          <v-btn color = "secondary" class = "white--text" @click = "next('1')">Back</v-btn>
                          <v-btn href="index.php">Cancel</v-btn>

                        </v-flex>
                        <v-flex style = "text-align:center">
                              <v-btn>Process</v-btn>

                        </v-flex>


                  </v-card>
                  </v-container>



              </v-app>

        </div>
      <?php  }else { ?>
        <h1 class = "display-3">You cannot access this page</h1>
        <a href = "index.php" class = "display-2">back</a>
      <?php } ?>

  </body>
</html>
