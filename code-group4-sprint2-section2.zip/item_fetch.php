<?php
      $conn = mysqli_connect("localhost","root","","mdb");
        if($conn->connect_error){
          die("Cannot connect to database");
        }


          mysqli_set_charset($conn, "utf8");
          $sqll = "SELECT *  FROM itemstock";
          $result = mysqli_query($conn,$sqll);
          $users = array();
          while($row = mysqli_fetch_assoc($result)){
            $bool = false;
            $diag = false;
            $row['bool'] = $bool;
            $users[] = $row;
          }

          echo json_encode($users);





?>
