<?php session_start();

      $_SESSION['orderID'] = time() . mt_rand() . $_SESSION['profID'];
      //echo $_SESSION['OrderID'];
?>
