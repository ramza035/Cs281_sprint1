<?php
session_start();
$host = "localhost";
$usr = "root";
$pwd = "";
$db = "mdb";
$isCorrect = false;
$con = new mysqli($host,$usr,$pwd,$db);
$username = $_REQUEST['usr'];
$password = $_REQUEST['pswd'];
$fn = $_REQUEST['fn'];
$ln = $_REQUEST['ln'];
$em = $_REQUEST['em'];
$ad = $_REQUEST['ad'];
if ($con->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
  $qu = "INSERT INTO user(name,password,fname,lname,address,email,permission) VALUES ('".$username."','".$password."','".$fn."','".$ln."','".$ad."','".$em."',0);";
  if($con->query($qu) === TRUE){
    echo "reg_success";
}else {
    echo "Error: " . $qu . "<br>" . $con->error;
}
 ?>
