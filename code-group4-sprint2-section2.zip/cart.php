<?php
    session_start();
    if(isset($_REQUEST['cart'])){
      //echo '<script>alert("'.count($_REQUEST['cart']).'")'.'</script>';

        $cart = $_REQUEST['cart'];
        $_SESSION['cart'] = $cart;
        if(isset($_REQUEST['tot'])){
              $_SESSION['tot'] = $_REQUEST['tot'];
        }

        echo json_encode($_SESSION['cart']);

    }
    if(isset($_REQUEST['reset'])){
      if($_REQUEST['reset'] == "true"){
        unset($_SESSION['cart']);
        unset($_REQUEST['reset']);
      }
    }
      echo json_encode($_SESSION['cart']);





?>
