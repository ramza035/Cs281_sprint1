window.onload = function(){
  var manage = new Vue({
    el : "#manage_item",
    data : {
      user_item : [],
      manage_open : false,
      temp_itemid : "",
      temp_itemname : "",
      temp_itemdesc : "",
      temp_price : "",
      temp_stock : ""
    },
    methods : {
      fetch(){
        $.getJSON("manageCtrl.php",function(res){
          this.user_item = res;

        }.bind(this))
      },
      open(id,name,desc,price,stock){

        this.temp_itemid = id;
        this.temp_itemdesc = desc;
        this.temp_itemname = name;
        this.temp_price = price;
        this.temp_stock = stock;
      },
      edit_product(name,desc,price,stock,itemid){
        $.get('manageCtrl.php',{operate : "edit",name : name ,desc : desc , price : price , stock : stock,itemid : itemid})
            .done(function(data)
            {
                alert("แก้ไขเรียบร้อย")
            })
      }
    },
    created : function(){
      this.fetch();
    }
  })
}
